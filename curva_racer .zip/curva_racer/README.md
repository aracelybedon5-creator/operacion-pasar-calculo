# Curva Racer — Simulador Inteligente de Curvatura

Simulador educativo e interactivo de conducción donde los jugadores diseñan pistas dinámicas y controlan vehículos adaptando la velocidad según la curvatura de cada tramo. Implementa conceptos de cálculo vectorial, física simplificada y optimización computacional.

## Características

- **Editor de pistas interactivo**: Añadir y editar puntos de control con arrastrado de ratón.
- **Cálculo real-time de curvatura (κ)**: Visualización coloreada (verde/amarillo/rojo).
- **Simulación física integrada**: Velocidad máxima por curvatura, detección de pérdida de control.
- **Splines Catmull-Rom adaptativos**: Generación de curvas suaves con discretización inteligente.
- **Disponible en Python (Pygame) y Web (p5.js)**.

## Requisitos

### Python (Versión de escritorio)

```
Python 3.10+
pip install -r requirements.txt
```

Instala:
- `pygame`: Visualización gráfica.
- `numpy`: Cálculos vectorizados.

### Web (Versión navegador)

Abre `index.html` directamente en cualquier navegador moderno. No requiere servidor.

## Uso Rápido

### Python: Ejecutar el editor

```powershell
pip install -r requirements.txt
python main.py
```

### Python: Ejecutar tests

```powershell
python test_curvature.py
```

### Python: Ejecutar benchmarks

```powershell
python benchmark.py
```

### Web: Abrir en navegador

Simplemente abre `index.html` en tu navegador.

## Controles

| Entrada         | Acción                    |
|-----------------|---------------------------|
| Click izquierdo | Añadir punto de control   |
| Arrastrar       | Mover punto               |
| **S**           | Generar spline            |
| **SPACE**       | Inicio/Pausa simulación   |
| **↑ / ↓**       | Acelerar/Frenar           |
| **C**           | Limpiar puntos            |
| **K**           | Guardar pista (Python)    |
| **L**           | Cargar pista (Python)     |
| **ESC**         | Salir                     |

## Archivos del Proyecto

```
curva_racer/
├── README.md                   # Este archivo
├── requirements.txt            # Dependencias Python
├── main.py                     # Editor/simulador Pygame
├── curvature.py                # Cálculo de curvatura y splines
├── physics.py                  # Simulación física
├── track_editor.py             # Persistencia de pistas
├── visualizer.py               # Utilidades de renderizado
├── test_curvature.py           # 9 tests unitarios (PASS)
├── benchmark.py                # Análisis de performance
├── index.html                  # Prototipo web
└── curva_racer.js              # Lógica web (p5.js)
```

## Conceptos Matemáticos

### Curvatura (κ)

```
κ(t) = |x'y'' - y'x''| / (x'² + y'²)^(3/2)
```

### Velocidad Máxima Segura

```
v_max(κ) = sqrt(μ * g / κ)
```

### Parámetro de Arco Normalizado

```
s_norm = s(t) / s_total  ∈ [0, 1]
```

## Tests (TODOS PASAN ✓)

```
[TEST 1] Circunferencia (κ debe ser ~1.0)...           ✓ PASSED
[TEST 2] Recta (κ debe ser ~0)...                      ✓ PASSED
[TEST 3] Parábola (κ en vértice debe ser ~2)...        ✓ PASSED
[TEST 4] Longitud de arco (circunferencia debe ser ~2π) ✓ PASSED
[TEST 5] Parámetro de arco normalizado...              ✓ PASSED
[TEST 6] Física: v_max(κ)...                           ✓ PASSED
[TEST 7] Pérdida de control...                         ✓ PASSED
[TEST 8] Simulador de vehículo...                      ✓ PASSED
[TEST 9] Catmull-Rom adaptativo...                     ✓ PASSED
```

## Performance

- **Spline Catmull-Rom** (50 samples): ~3.9ms/iter
- **Curvatura** (1000 puntos): ~0.29ms/iter
- **Arc-param** (1000 puntos): ~0.05ms/iter
- **Vectorización NumPy**: Optimiza todos los cálculos

## Versiones

- **v1.0.0**: Todas las mejoras completadas
  - ✓ Physics y arc-length
  - ✓ Editor avanzado (arrastrado, guardar/cargar)
  - ✓ Tests completos y benchmarks
  - ✓ Portado web (p5.js)

## Próximas Mejoras

1. Multijugador online
2. Tabla de puntuaciones
3. Generador procedural de pistas
4. Física avanzada (fuerzas laterales)
5. Replay system y telemetría

---

**Versión**: 1.0.0 | **Estado**: Completado ✓
