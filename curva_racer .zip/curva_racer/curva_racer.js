/**
 * CURVA RACER - Simulador Inteligente de Curvatura (Web Edition)
 * Implementado con p5.js
 * 
 * Características:
 * - Editor interactivo de pistas (click + arrastrar)
 * - Cálculo real-time de curvatura
 * - Simulación física simplificada
 * - Visualización coloreada por curvatura
 * - Guardado/carga de pistas en localStorage
 */

// Estado global
let canvas;
let controlPoints = [];
let curvePoints = [];
let kappas = [];
let vehicle = null;
let simulating = false;
let draggingIndex = null;
let mu = 0.9;  // coeficiente de fricción
let g = 981.0; // aceleración gravitacional (escala)

// Configuración
const CONTROL_POINT_RADIUS = 8;
const CONTROL_POINT_HOVER_RADIUS = 12;
const VEHICLE_RADIUS = 10;
const SAMPLES_PER_SEGMENT = 50;

// Clase: Vehículo simulado
class Vehicle {
    constructor() {
        this.speed = 0.0;
        this.arcPos = 0.0;
        this.position = null;
        this.lostControl = false;
        this.kappa = 0.0;
        this.vMax = Infinity;
    }
    
    update(dt, curvePoints, kappas) {
        if (curvePoints.length < 2) return;
        
        // Interpolate point on curve
        const idx = Math.floor(this.arcPos * (curvePoints.length - 1));
        const clampedIdx = Math.max(0, Math.min(curvePoints.length - 1, idx));
        
        // Get local curvature
        this.kappa = kappas[clampedIdx] || 0;
        
        // Calculate max velocity
        this.vMax = this.calculateVMax(this.kappa);
        
        // Apply control (auto-acceleration by default)
        let targetSpeed = Math.min(100, this.vMax * 0.95);
        let accel = 150; // pixels/s²
        
        if (this.speed < targetSpeed) {
            this.speed += accel * dt;
        } else {
            this.speed -= 200 * dt; // brake
        }
        this.speed = Math.max(0, this.speed);
        
        // Check loss of control
        this.lostControl = this.speed > (this.vMax + 5);
        if (this.lostControl) {
            this.speed -= 150 * dt;
            this.speed = Math.max(0, this.speed);
        }
        
        // Update arc position
        if (curvePoints.length > 1) {
            const totalLength = this.calculateTotalLength(curvePoints);
            if (totalLength > 0) {
                const ds = (this.speed * dt) / totalLength;
                this.arcPos += ds;
                if (this.arcPos > 1.0) {
                    this.arcPos = 1.0;
                }
            }
        }
        
        // Update position
        this.position = curvePoints[clampedIdx];
    }
    
    calculateVMax(kappa) {
        if (kappa <= 0) return Infinity;
        return Math.sqrt(mu * g / kappa);
    }
    
    calculateTotalLength(points) {
        let length = 0;
        for (let i = 0; i < points.length - 1; i++) {
            const dx = points[i+1].x - points[i].x;
            const dy = points[i+1].y - points[i].y;
            length += Math.sqrt(dx*dx + dy*dy);
        }
        return length;
    }
}

// p5.js setup
function setup() {
    let w = Math.min(window.innerWidth - 320, 900);
    let h = Math.min(window.innerHeight - 100, 600);
    canvas = createCanvas(w, h);
    canvas.parent('sketch-holder');
    
    // Load saved track
    loadTrack();
}

// p5.js draw loop
function draw() {
    background(30);
    
    // Draw curve with curvature colors
    if (curvePoints.length > 1) {
        for (let i = 0; i < curvePoints.length - 1; i++) {
            let col = getColorForKappa(kappas[i] || 0);
            stroke(...col);
            strokeWeight(3);
            line(curvePoints[i].x, curvePoints[i].y, 
                 curvePoints[i+1].x, curvePoints[i+1].y);
        }
    }
    
    // Update and draw vehicle
    if (vehicle) {
        if (simulating) {
            vehicle.update(deltaTime / 1000.0, curvePoints, kappas);
        }
        drawVehicle();
    }
    
    // Draw control points
    for (let i = 0; i < controlPoints.length; i++) {
        let p = controlPoints[i];
        let d = dist(mouseX, mouseY, p.x, p.y);
        let isHovered = d <= CONTROL_POINT_HOVER_RADIUS;
        
        fill(isHovered ? color(255, 150, 0) : color(200, 200, 200));
        noStroke();
        circle(p.x, p.y, isHovered ? CONTROL_POINT_HOVER_RADIUS * 2 : CONTROL_POINT_RADIUS * 2);
        
        // Label
        fill(0);
        textAlign(CENTER, CENTER);
        textSize(10);
        text(i, p.x, p.y);
    }
    
    // HUD
    drawHUD();
}

function drawVehicle() {
    if (!vehicle.position) return;
    
    let col = vehicle.lostControl ? color(255, 0, 0) : color(50, 200, 255);
    fill(col);
    noStroke();
    circle(vehicle.position.x, vehicle.position.y, VEHICLE_RADIUS * 2);
    
    // Update stats panel
    updateStatsPanel();
}

function drawHUD() {
    fill(200);
    textAlign(LEFT);
    textSize(12);
    let y = 20;
    text(`Puntos control: ${controlPoints.length}`, 10, y);
    y += 15;
    if (curvePoints.length > 0) {
        text(`Puntos curva: ${curvePoints.length}`, 10, y);
        y += 15;
        if (vehicle) {
            text(`κ_max: ${Math.max(...kappas).toFixed(4)}`, 10, y);
        }
    }
}

function updateStatsPanel() {
    if (!vehicle) return;
    
    document.getElementById('stat-speed').textContent = vehicle.speed.toFixed(1) + ' px/s';
    document.getElementById('stat-kappa').textContent = vehicle.kappa.toFixed(4);
    
    let vmaxText = isFinite(vehicle.vMax) ? vehicle.vMax.toFixed(1) + ' px/s' : '∞';
    document.getElementById('stat-vmax').textContent = vmaxText;
    
    let ratio = 0;
    if (isFinite(vehicle.vMax) && vehicle.vMax > 0) {
        ratio = (vehicle.speed / vehicle.vMax * 100).toFixed(0);
    }
    document.getElementById('stat-ratio').textContent = ratio + '%';
    
    document.getElementById('stat-pos').textContent = (vehicle.arcPos * 100).toFixed(1) + '%';
    
    let statusElem = document.getElementById('stat-status');
    if (vehicle.lostControl) {
        statusElem.className = 'stat status-danger';
        statusElem.innerHTML = '<label>Estado:</label><span class="value">✗ PERDIÓ CONTROL</span>';
    } else {
        statusElem.className = 'stat status-ok';
        statusElem.innerHTML = '<label>Estado:</label><span class="value">✓ Control OK</span>';
    }
    
    // Draw curvature graph
    drawCurvatureGraph();
}

// ═══════════════════════════════════════════════════════════════════
// Función para dibujar el gráfico de curvatura
// ═══════════════════════════════════════════════════════════════════
function drawCurvatureGraph() {
    const canvas = document.getElementById('curvature-graph');
    if (!canvas || kappas.length === 0) return;
    
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    const padding = 10;
    
    // Limpiar canvas
    ctx.fillStyle = 'rgba(30, 30, 40, 0.8)';
    ctx.fillRect(0, 0, width, height);
    
    // Marco
    ctx.strokeStyle = 'rgba(80, 80, 112, 0.5)';
    ctx.lineWidth = 1;
    ctx.strokeRect(1, 1, width - 2, height - 2);
    
    // Líneas de referencia horizontales
    ctx.strokeStyle = 'rgba(80, 80, 100, 0.2)';
    ctx.lineWidth = 1;
    for (let i = 1; i <= 2; i++) {
        const y = padding + (height - 2 * padding) * i / 3;
        ctx.beginPath();
        ctx.moveTo(padding, y);
        ctx.lineTo(width - padding, y);
        ctx.stroke();
    }
    
    // Encontrar max curvatura
    const maxKappa = Math.max(...kappas, 0.001);
    
    // Dibujar gráfico de curvatura
    const graphHeight = height - 2 * padding;
    const graphWidth = width - 2 * padding;
    
    for (let i = 0; i < kappas.length - 1; i++) {
        const x1 = padding + (i / kappas.length) * graphWidth;
        const x2 = padding + ((i + 1) / kappas.length) * graphWidth;
        const y1 = padding + graphHeight - (kappas[i] / maxKappa) * graphHeight;
        const y2 = padding + graphHeight - (kappas[i + 1] / maxKappa) * graphHeight;
        
        // Color según curvatura
        const col = getColorForKappa(kappas[i]);
        ctx.strokeStyle = `rgb(${col[0]}, ${col[1]}, ${col[2]})`;
        ctx.lineWidth = 2;
        
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
    }
    
    // Dibujar cursor de posición actual del vehículo
    if (vehicle && vehicle.arcPos >= 0 && vehicle.arcPos <= 1) {
        const cursorX = padding + vehicle.arcPos * graphWidth;
        
        // Línea vertical blanca
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(cursorX, padding);
        ctx.lineTo(cursorX, padding + graphHeight);
        ctx.stroke();
        
        // Círculo indicador
        ctx.fillStyle = 'rgba(255, 255, 100, 0.7)';
        ctx.beginPath();
        ctx.arc(cursorX, padding + graphHeight / 2, 5, 0, Math.PI * 2);
        ctx.fill();
        
        // Borde del círculo
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.lineWidth = 2;
        ctx.stroke();
    }
}

function getColorForKappa(k) {
    // 5 niveles de curvatura mejorados
    if (k < 0.05) return [100, 220, 100];     // Verde muy claro
    if (k < 0.1) return [50, 200, 50];        // Verde
    if (k < 0.2) return [200, 220, 50];       // Amarillo
    if (k < 0.35) return [230, 150, 30];      // Naranja
    return [220, 60, 60];                     // Rojo
}

// Catmull-Rom spline interpolation
function catmullRomChain(points, samplesPerSegment = 50) {
    if (points.length < 2) return points;
    
    let curve = [];
    
    // Add boundary points for smoothness
    let pts = [points[0], ...points, points[points.length - 1]];
    
    for (let i = 0; i < pts.length - 3; i++) {
        let p0 = pts[i];
        let p1 = pts[i + 1];
        let p2 = pts[i + 2];
        let p3 = pts[i + 3];
        
        for (let j = 0; j < samplesPerSegment; j++) {
            let t = j / samplesPerSegment;
            let t2 = t * t;
            let t3 = t2 * t;
            
            // Catmull-Rom basis functions
            let f1 = -0.5*t3 + t2 - 0.5*t;
            let f2 = 1.5*t3 - 2.5*t2 + 1.0;
            let f3 = -1.5*t3 + 2.0*t2 + 0.5*t;
            let f4 = 0.5*t3 - 0.5*t2;
            
            let pt = {
                x: f1*p0.x + f2*p1.x + f3*p2.x + f4*p3.x,
                y: f1*p0.y + f2*p1.y + f3*p2.y + f4*p3.y
            };
            curve.push(pt);
        }
    }
    
    curve.push(pts[pts.length - 2]);
    return curve;
}

// Calculate curvature along curve
function calculateCurvature(points) {
    if (points.length < 3) return new Array(points.length).fill(0);
    
    let kappas = [];
    
    // Use central differences for derivatives
    for (let i = 1; i < points.length - 1; i++) {
        let p0 = points[i - 1];
        let p1 = points[i];
        let p2 = points[i + 1];
        
        // Approximate derivatives
        let dx = (p2.x - p0.x) / 2;
        let dy = (p2.y - p0.y) / 2;
        let ddx = (p2.x - 2*p1.x + p0.x);
        let ddy = (p2.y - 2*p1.y + p0.y);
        
        // κ = |x'y'' - y'x''| / (x'^2 + y'^2)^(3/2)
        let num = Math.abs(dx*ddy - dy*ddx);
        let denom = Math.pow(dx*dx + dy*dy, 1.5);
        
        kappas.push(denom === 0 ? 0 : num / denom);
    }
    
    kappas.unshift(kappas[0] || 0);
    kappas.push(kappas[kappas.length - 1] || 0);
    
    return kappas;
}

// Mouse events
function mousePressed() {
    if (mouseX < 0 || mouseX > width || mouseY < 0 || mouseY > height) return false;
    
    // Check if dragging control point
    for (let i = 0; i < controlPoints.length; i++) {
        let d = dist(mouseX, mouseY, controlPoints[i].x, controlPoints[i].y);
        if (d <= CONTROL_POINT_HOVER_RADIUS) {
            draggingIndex = i;
            return false;
        }
    }
    
    // Add new control point
    controlPoints.push({x: mouseX, y: mouseY});
    return false;
}

function mouseDragged() {
    if (draggingIndex !== null) {
        controlPoints[draggingIndex].x = mouseX;
        controlPoints[draggingIndex].y = mouseY;
    }
    return false;
}

function mouseReleased() {
    draggingIndex = null;
}

// Keyboard events
function keyPressed() {
    if (key === 's' || key === 'S') {
        generateSpline();
        return false;
    } else if (key === 'p' || key === 'P') {
        toggleSimulation();
        return false;
    } else if (key === 'c' || key === 'C') {
        resetScene();
        return false;
    } else if (keyCode === UP_ARROW) {
        if (vehicle) vehicle.speed = Math.min(vehicle.speed + 50, 300);
        return false;
    } else if (keyCode === DOWN_ARROW) {
        if (vehicle) vehicle.speed = Math.max(vehicle.speed - 50, 0);
        return false;
    } else if (keyCode === ESCAPE) {
        // Reload page
        location.reload();
    }
    return false;
}

// Game functions
function generateSpline() {
    if (controlPoints.length < 2) {
        console.log("Necesita al menos 2 puntos de control");
        return;
    }
    
    curvePoints = catmullRomChain(controlPoints, SAMPLES_PER_SEGMENT);
    kappas = calculateCurvature(curvePoints);
    
    if (!vehicle) {
        vehicle = new Vehicle();
    }
    
    console.log(`Spline generado: ${curvePoints.length} puntos, κ_max = ${Math.max(...kappas).toFixed(4)}`);
    saveTrack();
}

function toggleSimulation() {
    if (curvePoints.length === 0) {
        console.log("Genere spline primero (S)");
        return;
    }
    simulating = !simulating;
    console.log(simulating ? "Simulación iniciada" : "Simulación pausada");
}

function resetScene() {
    controlPoints = [];
    curvePoints = [];
    kappas = [];
    vehicle = null;
    simulating = false;
    draggingIndex = null;
    saveTrack();
}

// Storage functions
function saveTrack() {
    localStorage.setItem('curvaRacerTrack', JSON.stringify(controlPoints));
}

function loadTrack() {
    let saved = localStorage.getItem('curvaRacerTrack');
    if (saved) {
        try {
            controlPoints = JSON.parse(saved);
            console.log(`Pista cargada: ${controlPoints.length} puntos`);
        } catch (e) {
            console.log("Error cargando pista");
        }
    }
}

// Global functions for buttons
function resetScene_global() {
    resetScene();
}

function toggleSimulation_global() {
    toggleSimulation();
}

window.resetScene = resetScene_global;
window.toggleSimulation = toggleSimulation_global;

// Handle window resize
window.addEventListener('resize', () => {
    if (typeof resizeCanvas === 'function') {
        let w = Math.min(window.innerWidth - 320, 900);
        let h = Math.min(window.innerHeight - 100, 600);
        resizeCanvas(w, h);
    }
});

// Log que todo está cargado
console.log('✓ curva_racer.js cargado');
