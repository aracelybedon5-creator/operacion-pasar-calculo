"""Funciones de ayuda para dibujar vectores tangentes/normales y leyendas.
Módulo pequeño para mantener `main.py` legible.
"""
import pygame
import math


def draw_vector(screen, origin, vec, color=(255,255,0), scale=1.0):
    ox, oy = int(origin[0]), int(origin[1])
    dx, dy = vec[0]*scale, vec[1]*scale
    pygame.draw.line(screen, color, (ox,oy), (ox+dx, oy+dy), 2)
    # punta
    ang = math.atan2(dy, dx)
    left = (ox+dx - 6*math.cos(ang-0.5), oy+dy - 6*math.sin(ang-0.5))
    right = (ox+dx - 6*math.cos(ang+0.5), oy+dy - 6*math.sin(ang+0.5))
    pygame.draw.polygon(screen, color, [(ox+dx, oy+dy), left, right])
