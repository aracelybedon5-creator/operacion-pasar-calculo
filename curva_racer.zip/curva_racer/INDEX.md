🏁 **CURVA RACER** — Simulador Inteligente de Curvatura
=====================================================

Bienvenido a **CURVA RACER**, un simulador educativo de conducción que demuestra conceptos avanzados de cálculo vectorial, física aplicada y optimización computacional.

## 📖 Documentación Rápida

| Archivo | Descripción |
|---------|-------------|
| **[README.md](README.md)** | Guía completa de uso y características |
| **[SUMMARY.md](SUMMARY.md)** | Resumen técnico detallado del proyecto |
| **start.bat** | Script de inicio rápido (Windows) |

## 🚀 Inicio Rápido

### Versión Web (Recomendado para empezar)
```
1. Abre index.html en tu navegador
2. ¡Listo! No requiere instalación
```

### Versión Python (Pygame)
```powershell
# 1. Instalar dependencias
pip install -r requirements.txt

# 2. Ejecutar editor
python main.py

# 3. O ejecutar tests
python test_curvature.py
```

## 🎮 Controles Básicos

- **Click izquierdo** → Añadir punto de control
- **Arrastrar** → Mover punto
- **S** → Generar spline
- **SPACE** → Iniciar/pausar simulación
- **↑ / ↓** → Acelerar/frenar
- **C** → Limpiar puntos

## 📊 Archivos Principales

```
curva_racer/
├── index.html              ← Versión web (p5.js)
├── main.py                 ← Versión Python (Pygame)
├── curvature.py            ← Cálculos matemáticos
├── physics.py              ← Simulación física
├── test_curvature.py       ← Tests (9/9 PASS ✓)
└── benchmark.py            ← Análisis de performance
```

## ✨ Características

- ✅ Cálculo real-time de curvatura (κ)
- ✅ Visualización coloreada (verde/amarillo/rojo)
- ✅ Simulación física: velocidad máxima por curvatura
- ✅ Detección de pérdida de control
- ✅ Splines Catmull-Rom adaptativos
- ✅ Disponible en Python y Web

## 🧮 Matemáticas Implementadas

**Curvatura (κ)**:
```
κ(t) = |x'y'' - y'x''| / (x'² + y'²)^(3/2)
```

**Velocidad máxima segura**:
```
v_max(κ) = √(μ·g / κ)
```

**Parámetro de arco normalizado**:
```
s_norm = s(t) / s_total ∈ [0, 1]
```

## ✅ Validación

Suite de 9 tests unitarios — **TODOS PASAN** ✓

```
[TEST 1] Circunferencia         ✓ PASS (error < 2%)
[TEST 2] Recta                  ✓ PASS (error < 1%)
[TEST 3] Parábola               ✓ PASS (κ ≈ 2)
[TEST 4] Longitud de arco       ✓ PASS (error < 1%)
[TEST 5] Parámetro arc-length   ✓ PASS (monótono)
[TEST 6] Física (v_max)         ✓ PASS (decreciente)
[TEST 7] Pérdida de control     ✓ PASS (detectado)
[TEST 8] Simulador vehículo     ✓ PASS (integración OK)
[TEST 9] Catmull-Rom adaptativo ✓ PASS
```

## 📈 Performance

- **Curvatura** (1000 pts): 0.29 ms/iter
- **Spline Catmull-Rom** (50 samples): 3.9 ms/iter
- **Arc-param** (1000 pts): 0.05 ms/iter

## 🎓 Conceptos Educativos

- Cálculo diferencial (derivadas)
- Geometría diferencial (curvatura)
- Física aplicada (dinámicas circulares)
- Algoritmos numéricos (Euler, interpolación)
- Optimización computacional (vectorización)

## 📞 Soporte

- Ejecuta tests: `python test_curvature.py`
- Ejecuta benchmarks: `python benchmark.py`
- Revisa [README.md](README.md) para detalles
- Lee [SUMMARY.md](SUMMARY.md) para arquitectura

## 🔮 Próximas Mejoras

1. Multijugador online
2. Tabla de puntuaciones
3. Generador procedural de pistas
4. Física avanzada
5. Portado a Unity

---

**Versión**: 1.0.0 | **Estado**: ✅ Completo | **Fecha**: 17/11/2025

¡Disfruta del simulador! 🏎️
