"""Benchmarking: analizar performance del cálculo de curvatura.
Ejecutar: python C:/xampp_/htdocs/curva_racer/benchmark.py
"""
import time
import numpy as np
from curvature import catmull_rom_chain, curvature_along_curve, arc_param

def make_circle(radius=1.0, n=500):
    t = np.linspace(0, 2*np.pi, n, endpoint=False)
    x = radius * np.cos(t)
    y = radius * np.sin(t)
    pts = np.vstack([x, y]).T
    return pts

def benchmark():
    print("\n" + "="*60)
    print("BENCHMARKING: CURVA RACER")
    print("="*60)
    
    # Test 1: Catmull-Rom con diferentes tamaños
    print("\n[BENCHMARK 1] Generación de spline Catmull-Rom")
    ctrl_pts = [(50 + i*50, 100 + (i%2)*100) for i in range(10)]
    
    for samples in [10, 50, 100, 200]:
        t0 = time.time()
        for _ in range(100):
            curve = catmull_rom_chain(ctrl_pts, samples_per_segment=samples, adaptive=False)
        elapsed = time.time() - t0
        curve_len = len(curve)
        print(f"  samples={samples:3d}: {curve_len:4d} puntos, {elapsed*1000:.2f}ms (100 iteraciones)")
    
    # Test 2: Curvatura en curvas de diferentes tamaños
    print("\n[BENCHMARK 2] Cálculo de curvatura")
    for n_pts in [100, 500, 1000, 5000]:
        curve = make_circle(1.0, n=n_pts)
        t0 = time.time()
        for _ in range(100):
            kappas = curvature_along_curve(curve)
        elapsed = time.time() - t0
        print(f"  {n_pts:4d} puntos: {elapsed*1000:.2f}ms (100 iteraciones)")
    
    # Test 3: Parámetro de arco
    print("\n[BENCHMARK 3] Parámetro de arco normalizado")
    for n_pts in [100, 500, 1000, 5000]:
        curve = make_circle(1.0, n=n_pts)
        t0 = time.time()
        for _ in range(100):
            s_param = arc_param(curve)
        elapsed = time.time() - t0
        print(f"  {n_pts:4d} puntos: {elapsed*1000:.2f}ms (100 iteraciones)")
    
    # Test 4: Spline adaptativo vs regular
    print("\n[BENCHMARK 4] Adaptive vs Regular Catmull-Rom")
    ctrl_pts_complex = [(50 + i*30, 100 + np.sin(i)*50) for i in range(20)]
    
    t0 = time.time()
    for _ in range(10):
        curve_regular = catmull_rom_chain(ctrl_pts_complex, samples_per_segment=50, adaptive=False)
    time_regular = time.time() - t0
    
    t0 = time.time()
    for _ in range(10):
        curve_adaptive = catmull_rom_chain(ctrl_pts_complex, samples_per_segment=50, adaptive=True)
    time_adaptive = time.time() - t0
    
    print(f"  Regular: {len(curve_regular):4d} puntos, {time_regular*1000:.2f}ms (10 iteraciones)")
    print(f"  Adaptive: {len(curve_adaptive):4d} puntos, {time_adaptive*1000:.2f}ms (10 iteraciones)")
    print(f"  Overhead adaptativo: {((time_adaptive/time_regular)-1)*100:.1f}%")
    
    print("\n" + "="*60)
    print("RESUMEN: Vectorización NumPy optimiza performance.")
    print("Recomendación: Usar adaptive=True para pistas complejas.")
    print("="*60 + "\n")

if __name__ == '__main__':
    benchmark()
