"""Cálculo de spline Catmull-Rom y curvatura (κ)
Funciones principales:
- catmull_rom_chain(control_points, samples_per_segment, adaptive=False)
- curvature_along_curve(points) -> devuelve array de κ para cada punto
- arc_length(curve_points) -> devuelve longitud total de arco
- arc_param(curve_points) -> devuelve parámetro de arco normalizado s ∈ [0,1]
- curve_point_at_arc(curve_points, s) -> interpolación en parámetro s
"""
from math import hypot, sqrt
import numpy as np

def catmull_rom_chain(points, samples_per_segment=50, closed=False, adaptive=False):
    """Genera una lista de puntos (x,y) interpolados por Catmull-Rom.
    points: lista de (x,y)
    samples_per_segment: puntos base por cada segmento entre puntos de control
    closed: si la pista es cerrada
    adaptive: si True, aumenta densidad en segmentos con curvatura alta
    Devuelve: numpy array de shape (N,2)
    """
    pts = np.array(points, dtype=float)
    if pts.shape[0] < 2:
        return pts
    if closed:
        # añadir envoltura
        pts = np.vstack([pts, pts[0], pts[1]])
        start = 0
        end = pts.shape[0] - 3
    else:
        # añadir extremos duplicados para mantener suavidad en los bordes
        pts = np.vstack([pts[0], pts, pts[-1]])
        start = 0
        end = pts.shape[0] - 3

    curve = []
    for i in range(start, end):
        p0 = pts[i]
        p1 = pts[i+1]
        p2 = pts[i+2]
        p3 = pts[i+3]
        # si adaptive, estimar curvatura del segmento y ajustar samples
        seg_samples = samples_per_segment
        if adaptive:
            # muestreo provisional
            temp_pts = []
            for j in range(10):
                t = j / 10.0
                t2, t3 = t*t, t*t*t
                f1 = -0.5*t3 + t2 - 0.5*t
                f2 =  1.5*t3 - 2.5*t2 + 1.0
                f3 = -1.5*t3 + 2.0*t2 + 0.5*t
                f4 =  0.5*t3 - 0.5*t2
                temp_pts.append(f1*p0 + f2*p1 + f3*p2 + f4*p3)
            temp_arr = np.array(temp_pts)
            k_temp = curvature_along_curve(temp_arr)
            mean_k = np.mean(k_temp)
            # aumentar samples si hay curvatura significativa
            seg_samples = int(samples_per_segment * (1.0 + 2.0*mean_k))
        
        for j in range(seg_samples):
            t = j / seg_samples
            t2 = t*t
            t3 = t2*t
            # Catmull-Rom basis
            f1 = -0.5*t3 + t2 - 0.5*t
            f2 =  1.5*t3 - 2.5*t2 + 1.0
            f3 = -1.5*t3 + 2.0*t2 + 0.5*t
            f4 =  0.5*t3 - 0.5*t2
            point = f1*p0 + f2*p1 + f3*p2 + f4*p3
            curve.append(point)
    # añadir último punto p_{n-1}
    curve.append(pts[-2])
    return np.array(curve)


def curvature_along_curve(curve_points):
    """Calcula la curvatura κ para cada punto de una curva discretizada.
    curve_points: numpy array shape (N,2) con posiciones ordenadas.
    Devuelve: numpy array shape (N,) con valores de κ (float)."""
    if len(curve_points) < 3:
        return np.zeros(len(curve_points))
    x = curve_points[:,0]
    y = curve_points[:,1]
    # suponer parámetros uniformes; usar np.gradient
    dx = np.gradient(x)
    dy = np.gradient(y)
    ddx = np.gradient(dx)
    ddy = np.gradient(dy)
    # κ = |x' y'' - y' x''| / (x'^2 + y'^2)^(3/2)
    num = np.abs(dx*ddy - dy*ddx)
    denom = (dx*dx + dy*dy)**1.5
    # evitar división por cero
    with np.errstate(divide='ignore', invalid='ignore'):
        k = np.where(denom==0, 0.0, num/denom)
    return k

# Utilidad: calcular longitud de arco aproximada
def arc_length(curve_points):
    diffs = np.diff(curve_points, axis=0)
    seg_lengths = np.hypot(diffs[:,0], diffs[:,1])
    return np.sum(seg_lengths)

def arc_param(curve_points):
    """Calcula parámetro de arco normalizado s ∈ [0,1] para cada punto.
    curve_points: numpy array shape (N,2)
    Devuelve: numpy array shape (N,) con valores s normalizados.
    """
    if len(curve_points) < 2:
        return np.zeros(len(curve_points))
    diffs = np.diff(curve_points, axis=0)
    seg_lengths = np.hypot(diffs[:,0], diffs[:,1])
    cumsum = np.concatenate([[0], np.cumsum(seg_lengths)])
    total_len = cumsum[-1]
    if total_len == 0:
        return np.linspace(0, 1, len(curve_points))
    return cumsum / total_len

def curve_point_at_arc(curve_points, s):
    """Interpola un punto en la curva dados parámetro de arco s ∈ [0,1].
    curve_points: numpy array shape (N,2)
    s: float en [0,1] o array de valores s
    Devuelve: punto (x,y) o array de puntos.
    """
    s_arr = np.atleast_1d(s)
    s_norm = arc_param(curve_points)
    result = []
    for s_val in s_arr:
        s_val = np.clip(s_val, 0.0, 1.0)
        idx = np.searchsorted(s_norm, s_val)
        if idx >= len(curve_points):
            idx = len(curve_points) - 1
        if idx == 0:
            result.append(curve_points[0])
        else:
            # interpolar linealmente entre curve_points[idx-1] e curve_points[idx]
            t = (s_val - s_norm[idx-1]) / (s_norm[idx] - s_norm[idx-1]) if s_norm[idx] != s_norm[idx-1] else 0
            t = np.clip(t, 0, 1)
            pt = (1-t) * curve_points[idx-1] + t * curve_points[idx]
            result.append(pt)
    if np.isscalar(s):
        return result[0]
    return np.array(result)
