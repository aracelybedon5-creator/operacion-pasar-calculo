"""CURVA RACER - Simulador Visual de Curvatura v2.0
Interface mejorada con cálculos en tiempo real y visualización avanzada.

CONTROLES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🖱️  MOUSE:
    • CLICK: Añadir punto de control
    • DRAG: Mover punto de control
    
⌨️  TECLADO:
    • S: Generar/regenerar spline
    • P: Iniciar/pausar simulación
    • UP/DOWN: Acelerar/frenar vehículo
    • C: Limpiar pista
    • K: Guardar pista
    • L: Cargar pista
    • H: Mostrar/ocultar ayuda
    • ESC: Salir
"""
import sys
import os
import math
import json
import numpy as np
import pygame
from curvature import catmull_rom_chain, curvature_along_curve, arc_param
from physics import VehicleSimulator, v_max
from track_editor import save_control_points, load_control_points

WIDTH, HEIGHT = 1400, 850
BG = (20, 20, 25)
CONTROL_POINT_RADIUS = 8
CONTROL_POINT_HOVER_RADIUS = 12
PANEL_WIDTH = 280
GRAPH_HEIGHT = 120

def color_for_kappa(k):
    """Retorna color según la curvatura (más intuitivo)."""
    if k < 0.05:
        return (100, 220, 100)  # Verde claro - muy suave
    elif k < 0.1:
        return (50, 200, 50)    # Verde - suave
    elif k < 0.2:
        return (200, 220, 50)   # Amarillo - moderado
    elif k < 0.35:
        return (230, 150, 30)   # Naranja - fuerte
    else:
        return (220, 60, 60)    # Rojo - muy fuerte


def draw_kappa_graph(screen, font, kappas, vehicle_arc_pos, curve_width=900, graph_height=GRAPH_HEIGHT):
    """Dibuja un gráfico de curvatura vs posición en la pista."""
    if kappas is None or len(kappas) == 0:
        return
    
    panel_x = WIDTH - PANEL_WIDTH - 10
    graph_y = HEIGHT - graph_height - 10
    
    # Marco del gráfico
    pygame.draw.rect(screen, (60, 60, 70), (panel_x - curve_width - 10, graph_y, curve_width + 20, graph_height + 20))
    pygame.draw.rect(screen, (120, 120, 140), (panel_x - curve_width - 10, graph_y, curve_width + 20, graph_height + 20), 2)
    
    # Normalizar curvatura
    kappa_max = max(kappas) if max(kappas) > 0 else 1.0
    kappa_min = 0
    
    # Dibujar líneas de referencia
    for i in range(3):
        y = graph_y + 5 + (graph_height - 10) * i / 2
        pygame.draw.line(screen, (80, 80, 90), (panel_x - curve_width - 5, y), (panel_x + 5, y), 1)
    
    # Dibujar gráfico de curvatura
    for i in range(len(kappas) - 1):
        x1 = panel_x - curve_width + (i / len(kappas)) * curve_width
        x2 = panel_x - curve_width + ((i + 1) / len(kappas)) * curve_width
        y1 = graph_y + graph_height - 5 - ((kappas[i] / kappa_max) * (graph_height - 10))
        y2 = graph_y + graph_height - 5 - ((kappas[i + 1] / kappa_max) * (graph_height - 10))
        
        # Color del segmento según curvatura
        col = color_for_kappa(kappas[i])
        pygame.draw.line(screen, col, (int(x1), int(y1)), (int(x2), int(y2)), 2)
    
    # Marcador de posición actual del vehículo
    if vehicle_arc_pos is not None:
        cursor_x = panel_x - curve_width + (vehicle_arc_pos * curve_width)
        pygame.draw.line(screen, (255, 255, 255), (cursor_x, graph_y + 5), (cursor_x, graph_y + graph_height - 5), 3)
        pygame.draw.circle(screen, (255, 255, 100), (int(cursor_x), int(graph_y + graph_height / 2)), 5)
    
    # Etiqueta
    label = font.render("Curvatura vs Posición", True, (200, 200, 200))
    screen.blit(label, (panel_x - curve_width - 5, graph_y - 20))
    
    # Escala
    kappa_label = font.render(f"κ: 0.0 → {kappa_max:.3f}", True, (150, 150, 150))
    screen.blit(kappa_label, (panel_x - 120, graph_y + graph_height + 5))


def draw_legend(screen, font):
    """Dibuja leyenda de colores para curvatura."""
    legend_x = WIDTH - PANEL_WIDTH - 280
    legend_y = 10
    
    # Marco de leyenda
    pygame.draw.rect(screen, (50, 50, 60), (legend_x - 5, legend_y - 5, 260, 130))
    pygame.draw.rect(screen, (100, 100, 120), (legend_x - 5, legend_y - 5, 260, 130), 2)
    
    title = font.render("Niveles de Curvatura", True, (220, 220, 220))
    screen.blit(title, (legend_x + 5, legend_y + 2))
    
    levels = [
        ("Muy suave", 0.025, (100, 220, 100)),
        ("Suave", 0.075, (50, 200, 50)),
        ("Moderado", 0.15, (200, 220, 50)),
        ("Fuerte", 0.275, (230, 150, 30)),
        ("Muy fuerte", 0.4, (220, 60, 60)),
    ]
    
    y = legend_y + 25
    for label, kappa, color in levels:
        # Caja de color
        pygame.draw.rect(screen, color, (legend_x + 5, y, 15, 12))
        pygame.draw.rect(screen, (200, 200, 200), (legend_x + 5, y, 15, 12), 1)
        
        # Texto con rango
        text = font.render(f"{label} (κ ≈ {kappa:.3f})", True, (200, 200, 200))
        screen.blit(text, (legend_x + 25, y - 2))
        y += 18


def draw_info_panel(screen, font_small, font_large, vehicle, control_points, kappas, frame, running, show_help=False):
    """Dibuja panel derecho con información detallada."""
    panel_x = WIDTH - PANEL_WIDTH
    panel_y = 10
    
    # Fondo del panel
    pygame.draw.rect(screen, (40, 40, 50), (panel_x - 5, panel_y - 5, PANEL_WIDTH + 5, 330))
    pygame.draw.rect(screen, (100, 100, 120), (panel_x - 5, panel_y - 5, PANEL_WIDTH + 5, 330), 2)
    
    lines = []
    
    # Título
    title = "🏁 CURVA RACER"
    title_surf = font_large.render(title, True, (255, 200, 100))
    screen.blit(title_surf, (panel_x, panel_y))
    
    y = panel_y + 35
    
    # Información de pista
    lines.append(f"Puntos control: {len(control_points) if control_points else 0}")
    lines.append(f"Estado: {'🎬 CORRIENDO' if running else '⏸️  PAUSADO'}")
    
    if vehicle and kappas is not None and len(kappas) > 0:
        # Información de velocidad
        speed = vehicle.state.get('speed', 0)
        vmax = vehicle.state.get('vmax', float('inf'))
        kappa = vehicle.state.get('kappa', 0)
        arc = vehicle.arc_pos * 100 if vehicle.arc_pos is not None else 0
        
        lines.append("")
        lines.append(f"Velocidad: {speed:.1f} px/s")
        if not math.isinf(vmax):
            lines.append(f"V_máx: {vmax:.1f} px/s")
            ratio = (speed / vmax * 100) if vmax > 0 else 0
            lines.append(f"Ocupado: {ratio:.0f}%")
        
        lines.append("")
        lines.append(f"Curvatura: κ = {kappa:.5f}")
        lines.append(f"Posición: {arc:.1f}%")
        
        if vehicle.lost_control:
            lines.append("")
            lines.append("⚠️  ¡PERDIÓ CONTROL! ⚠️")
        
        lines.append("")
        lines.append(f"Frame: {frame}")
    
    # Dibujar líneas de información
    for line in lines:
        if "CONTROL" in line:
            color = (255, 100, 100)
        elif "CORRIENDO" in line:
            color = (100, 255, 100)
        else:
            color = (200, 200, 220)
        
        surf = font_small.render(line, True, color)
        screen.blit(surf, (panel_x + 5, y))
        y += 18
    
    # Instrucciones rápidas
    y += 10
    instructions = [
        "━━ INSTRUCCIONES ━━",
        "S: Generar spline",
        "SPACE: Iniciar/pausar",
        "UP/DOWN: Accel/freno",
        "C: Limpiar",
        "K: Guardar | L: Cargar",
        "H: Ayuda | ESC: Salir",
    ]
    
    for instruction in instructions:
        if "━" in instruction:
            color = (150, 150, 180)
        else:
            color = (180, 180, 200)
        surf = font_small.render(instruction, True, color)
        screen.blit(surf, (panel_x + 5, y))
        y += 16


def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption('🏁 CURVA RACER v2.0 - Simulador de Curvatura')
    clock = pygame.time.Clock()

    control_points = []
    curve = None
    kappas = None
    running_vehicle = False
    vehicle = None
    frame = 0
    s_param = None
    show_help = False
    
    dragging_idx = None
    
    font_small = pygame.font.SysFont(None, 14)
    font_medium = pygame.font.SysFont(None, 16)
    font_large = pygame.font.SysFont(None, 18)

    # Cargar pista anterior o crear demostración
    track_path = "track.json"
    if os.path.exists(track_path):
        try:
            control_points = load_control_points(track_path)
            print(f"✓ Pista cargada: {len(control_points)} puntos de control")
        except Exception as e:
            print(f"✗ Error cargando pista: {e}")
    else:
        # Pista de demostración
        control_points = [
            (150, 250), (300, 150), (500, 200), (700, 100),
            (950, 250), (1100, 450), (900, 600), (600, 550),
        ]
        print(f"✓ Pista de demostración creada: {len(control_points)} puntos")
        try:
            curve = catmull_rom_chain(control_points, samples_per_segment=50, adaptive=True)
            kappas = curvature_along_curve(curve)
            s_param = arc_param(curve)
            vehicle = VehicleSimulator(mu=0.9, g=981.0, target_speed=150)
            vehicle.state = {'pos': curve[0], 'speed': 0.0, 'lost': False, 'kappa': 0.0, 'vmax': float('inf')}
            print(f"✓ Spline generado: {len(curve)} puntos, κ_max = {np.max(kappas):.4f}")
        except Exception as e:
            print(f"✗ Error generando spline: {e}")

    print("\n" + "="*50)
    print("🏁 CURVA RACER v2.0 - ¡Bienvenido!")
    print("="*50)
    print("Presiona H para ver ayuda detallada")
    print("="*50 + "\n")

    while True:
        dt = clock.tick(60) / 1000.0
        frame += 1
        
        for e in pygame.event.get():
            if e.type == pygame.QUIT or (e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE):
                print("✓ Programa cerrado correctamente")
                pygame.quit()
                sys.exit()
            elif e.type == pygame.MOUSEBUTTONDOWN:
                if e.button == 1:
                    pos = pygame.mouse.get_pos()
                    for i, p in enumerate(control_points):
                        dist = math.hypot(pos[0] - p[0], pos[1] - p[1])
                        if dist <= CONTROL_POINT_HOVER_RADIUS:
                            dragging_idx = i
                            break
                    if dragging_idx is None and pos[0] < WIDTH - PANEL_WIDTH - 50:
                        control_points.append(pos)
            elif e.type == pygame.MOUSEBUTTONUP:
                if e.button == 1:
                    dragging_idx = None
            elif e.type == pygame.MOUSEMOTION:
                if dragging_idx is not None:
                    pos = pygame.mouse.get_pos()
                    if pos[0] < WIDTH - PANEL_WIDTH - 50:
                        control_points[dragging_idx] = pos
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_s:
                    if len(control_points) >= 2:
                        curve = catmull_rom_chain(control_points, samples_per_segment=50, adaptive=True)
                        kappas = curvature_along_curve(curve)
                        s_param = arc_param(curve)
                        vehicle = VehicleSimulator(mu=0.9, g=981.0, target_speed=150)
                        vehicle.state = {'pos': curve[0], 'speed': 0.0, 'lost': False, 'kappa': 0.0, 'vmax': float('inf')}
                        running_vehicle = False
                        print(f"✓ Spline generado: {len(curve)} puntos, κ_max = {np.max(kappas):.4f}")
                elif e.key == pygame.K_p:
                    if curve is not None:
                        running_vehicle = not running_vehicle
                        estado = "INICIADA" if running_vehicle else "PAUSADA"
                        print(f"✓ Simulación {estado}")
                elif e.key == pygame.K_c:
                    control_points = []
                    curve = None
                    kappas = None
                    vehicle = None
                    running_vehicle = False
                    print("✓ Pista limpiada")
                elif e.key == pygame.K_k:
                    try:
                        save_control_points(track_path, control_points)
                        print(f"✓ Pista guardada: {len(control_points)} puntos")
                    except Exception as ex:
                        print(f"✗ Error guardando: {ex}")
                elif e.key == pygame.K_l:
                    try:
                        control_points = load_control_points(track_path)
                        curve = None
                        kappas = None
                        vehicle = None
                        running_vehicle = False
                        print(f"✓ Pista cargada: {len(control_points)} puntos")
                    except Exception as ex:
                        print(f"✗ Error cargando: {ex}")
                elif e.key == pygame.K_UP:
                    if vehicle:
                        vehicle.speed = min(vehicle.speed + 50, 300)
                elif e.key == pygame.K_DOWN:
                    if vehicle:
                        vehicle.speed = max(vehicle.speed - 50, 0)
                elif e.key == pygame.K_h:
                    show_help = not show_help
                    if show_help:
                        print(__doc__)

        screen.fill(BG)

        # Dibujar curva coloreada
        if curve is not None and kappas is not None:
            for i in range(len(curve) - 1):
                p1 = curve[i]
                p2 = curve[i + 1]
                col = color_for_kappa(kappas[i])
                pygame.draw.line(screen, col, (int(p1[0]), int(p1[1])), (int(p2[0]), int(p2[1])), 3)

            # Simulación del vehículo
            if vehicle:
                if running_vehicle:
                    user_accel = 0.1
                    vehicle.state = vehicle.update(dt, curve, kappas, s_param, user_accel)
                else:
                    if not vehicle.state or vehicle.state.get('pos') is None:
                        vehicle.state = {'pos': curve[0], 'speed': 0.0, 'lost': False, 'kappa': 0.0, 'vmax': float('inf')}
                
                pos = vehicle.state.get('pos')
                if pos is not None:
                    # Vehículo con sombra
                    col = (255, 50, 50) if vehicle.lost_control else (50, 200, 255)
                    pygame.draw.circle(screen, (0, 0, 0), (int(pos[0]) + 2, int(pos[1]) + 2), 12)
                    pygame.draw.circle(screen, col, (int(pos[0]), int(pos[1])), 10)
                    pygame.draw.circle(screen, (100, 255, 100) if not vehicle.lost_control else (255, 100, 100), 
                                     (int(pos[0]), int(pos[1])), 10, 2)

        # Dibujar puntos de control
        mouse_pos = pygame.mouse.get_pos()
        for i, p in enumerate(control_points):
            dist = math.hypot(mouse_pos[0] - p[0], mouse_pos[1] - p[1])
            r = CONTROL_POINT_HOVER_RADIUS if dist <= CONTROL_POINT_HOVER_RADIUS else CONTROL_POINT_RADIUS
            col = (255, 200, 50) if dist <= CONTROL_POINT_HOVER_RADIUS else (180, 180, 200)
            pygame.draw.circle(screen, col, (int(p[0]), int(p[1])), r)
            pygame.draw.circle(screen, (100, 100, 120), (int(p[0]), int(p[1])), r, 2)
            label = font_small.render(str(i), True, (10, 10, 10))
            screen.blit(label, (int(p[0]) - 3, int(p[1]) - 3))

        # Panel derecho
        draw_info_panel(screen, font_small, font_large, vehicle, control_points, kappas, frame, running_vehicle, show_help)
        
        # Leyenda de colores
        draw_legend(screen, font_medium)
        
        # Gráfico de curvatura
        if vehicle:
            draw_kappa_graph(screen, font_small, kappas, vehicle.arc_pos)

        pygame.display.flip()


if __name__ == '__main__':
    main()

