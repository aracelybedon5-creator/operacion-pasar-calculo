"""Funciones físicas simplificadas para Curva Racer
- v_max(mu, g, kappa)
- check_loss_of_control(v, mu, g, kappa, tol)
- VehicleSimulator: clase de integración numérica de movimiento
"""
import math

def v_max(mu, g, kappa, min_kappa=1e-6):
    """Velocidad máxima segura dada la curvatura (κ). Si κ es cero (recta), devuelve un valor grande."""
    if kappa <= 0:
        return float('inf')
    return math.sqrt(mu * g / kappa)


def check_loss_of_control(v, mu, g, kappa, tol=0.0):
    """Devuelve True si la velocidad v excede v_max + tol"""
    vmax = v_max(mu, g, kappa)
    if math.isinf(vmax):
        return False
    return v > (vmax + tol)


class VehicleSimulator:
    """Simulador de vehículo con integración numérica.
    Parámetros:
    - mu: coeficiente de fricción
    - g: aceleración gravitacional
    - max_accel: aceleración máxima (px/s²)
    - max_brake: desaceleración máxima (px/s²)
    - target_speed: velocidad objetivo base (px/s)
    """
    def __init__(self, mu=0.9, g=981.0, max_accel=200, max_brake=300, target_speed=150):
        self.mu = mu
        self.g = g
        self.max_accel = max_accel
        self.max_brake = max_brake
        self.target_speed = target_speed
        self.speed = 0.0
        self.arc_pos = 0.0  # parámetro de arco normalizado [0,1]
        self.lost_control = False
        self.time_lost = 0.0
    
    def update(self, dt, curve_points, kappas, s_param, user_input_accel=0.0):
        """Integración numérica de un paso temporal.
        dt: delta tiempo en segundos
        curve_points: array de puntos de la curva
        kappas: array de curvatura para cada punto
        s_param: array de parámetro de arco normalizado (desde curvature.arc_param)
        user_input_accel: aceleración deseada del usuario [-1, 1] (escala de max_accel/brake)
        Devuelve: diccionario con estado de actualización
        """
        if not len(curve_points) or not len(kappas):
            return {'pos': None, 'speed': 0.0, 'lost': False, 'kappa': 0.0}
        
        # interpolar índice de arco
        idx = int(self.arc_pos * (len(curve_points) - 1))
        idx = max(0, min(len(curve_points) - 1, idx))
        
        # curvatura local
        kappa = kappas[idx]
        
        # velocidad máxima segura
        vmax = v_max(self.mu, self.g, kappa)
        
        # control de velocidad
        target_speed_local = min(self.target_speed, vmax * 0.95)
        
        # aceleración/frenada
        if user_input_accel > 0:
            accel = self.max_accel * user_input_accel
        else:
            accel = -self.max_brake * abs(user_input_accel)
        
        # integración: v(t+dt) = v(t) + a*dt
        self.speed += accel * dt
        
        # límites de velocidad
        self.speed = max(0.0, self.speed)
        
        # pérdida de control si v > vmax
        tolerance = 5.0
        self.lost_control = check_loss_of_control(self.speed, self.mu, self.g, kappa, tol=tolerance)
        
        if self.lost_control:
            self.time_lost += dt
            # desacelerar forzadamente en pérdida de control
            self.speed -= self.max_brake * 0.5 * dt
            self.speed = max(0.0, self.speed)
        
        # integración de posición (usando longitud de arco normalizada)
        # sumar distancia recorrida a arc_pos
        curve_length = sum(((curve_points[i+1] - curve_points[i])**2).sum()**0.5 
                           for i in range(len(curve_points)-1))
        if curve_length > 0:
            ds = self.speed * dt / curve_length
            self.arc_pos += ds
            if self.arc_pos > 1.0:
                self.arc_pos = 1.0
        
        return {
            'pos': curve_points[idx],
            'speed': self.speed,
            'lost': self.lost_control,
            'kappa': kappa,
            'vmax': vmax,
            's': self.arc_pos
        }
