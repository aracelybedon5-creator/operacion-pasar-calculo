"""Tests completos para validar curvatura, arc-length, y física.
Ejecutar: python C:/xampp_/htdocs/curva_racer/test_curvature.py

Casos de prueba:
1. Circunferencia: κ = 1/R (debe ser constante)
2. Recta: κ = 0 (debe ser cercano a cero)
3. Parábola: κ(x) = 2 / (1 + 4x²)^(3/2)
4. Longitud de arco y parámetro normalizado
5. Física: v_max y pérdida de control
"""
import numpy as np
from curvature import (curvature_along_curve, catmull_rom_chain, arc_length, arc_param, curve_point_at_arc)
from physics import v_max, check_loss_of_control, VehicleSimulator


def make_circle(radius=1.0, n=500):
    t = np.linspace(0, 2*np.pi, n, endpoint=False)
    x = radius * np.cos(t)
    y = radius * np.sin(t)
    pts = np.vstack([x, y]).T
    return pts


def make_line(start=(0, 0), end=(10, 0), n=100):
    t = np.linspace(0, 1, n)
    x = (1-t) * start[0] + t * end[0]
    y = (1-t) * start[1] + t * end[1]
    pts = np.vstack([x, y]).T
    return pts


def make_parabola(n=500):
    """y = x² en rango [-1, 1]"""
    x = np.linspace(-1, 1, n)
    y = x**2
    pts = np.vstack([x, y]).T
    return pts


def test_circle():
    """Test 1: Circunferencia tiene κ = 1/R constante"""
    print("\n[TEST 1] Circunferencia (κ debe ser ~1.0)...")
    pts = make_circle(1.0, n=500)
    kappas = curvature_along_curve(pts)
    mean_k = np.mean(kappas)
    max_k = np.max(kappas)
    std_k = np.std(kappas)
    print(f"  κ_mean = {mean_k:.6f}, κ_max = {max_k:.6f}, σ = {std_k:.6f}")
    assert abs(mean_k - 1.0) < 0.02, f"Curvatura media fuera de tolerancia: {mean_k}"
    assert std_k < 0.05, f"Varianza demasiado alta: {std_k}"
    print("  ✓ PASSED")


def test_line():
    """Test 2: Recta tiene κ = 0"""
    print("\n[TEST 2] Recta (κ debe ser ~0)...")
    pts = make_line((0, 0), (100, 0), n=100)
    kappas = curvature_along_curve(pts)
    mean_k = np.mean(kappas)
    max_k = np.max(kappas)
    print(f"  κ_mean = {mean_k:.6f}, κ_max = {max_k:.6f}")
    assert mean_k < 0.01, f"Curvatura media debería ser ~0: {mean_k}"
    print("  ✓ PASSED")


def test_parabola():
    """Test 3: Parábola y=x² tiene curvatura κ(0)=2"""
    print("\n[TEST 3] Parábola (κ en vértice debe ser ~2)...")
    pts = make_parabola(n=500)
    kappas = curvature_along_curve(pts)
    # κ en vértice (x=0) debe ser máxima
    mid_idx = len(kappas) // 2
    k_mid = kappas[mid_idx]
    print(f"  κ(vértice) = {k_mid:.6f}")
    # tolerancia más amplia por discretización
    assert 1.5 < k_mid < 2.5, f"Curvatura en vértice fuera de rango: {k_mid}"
    print("  ✓ PASSED")


def test_arc_length():
    """Test 4: Longitud de arco de circunferencia es 2πR"""
    print("\n[TEST 4] Longitud de arco (circunferencia debe ser ~2π)...")
    r = 1.0
    pts = make_circle(r, n=1000)
    length = arc_length(pts)
    expected = 2 * np.pi * r
    error = abs(length - expected) / expected
    print(f"  L = {length:.6f}, esperado = {expected:.6f}, error = {error*100:.2f}%")
    assert error < 0.01, f"Error de longitud demasiado alto: {error*100:.2f}%"
    print("  ✓ PASSED")


def test_arc_param():
    """Test 5: Parámetro de arco normalizado"""
    print("\n[TEST 5] Parámetro de arco normalizado...")
    pts = make_circle(1.0, n=100)
    s_param = arc_param(pts)
    assert s_param[0] == 0.0, "s en inicio debe ser 0"
    assert s_param[-1] == 1.0, "s al final debe ser 1"
    assert np.all(np.diff(s_param) >= 0), "s debe ser monótono"
    print(f"  s_inicio = {s_param[0]:.6f}, s_final = {s_param[-1]:.6f}")
    print("  ✓ PASSED")


def test_physics_vmax():
    """Test 6: v_max disminuye con curvatura"""
    print("\n[TEST 6] Física: v_max(κ)...")
    mu, g = 0.9, 9.81 * 100
    k_low = 0.01
    k_high = 0.5
    v_low = v_max(mu, g, k_low)
    v_high = v_max(mu, g, k_high)
    print(f"  v_max(κ=0.01) = {v_low:.2f}, v_max(κ=0.5) = {v_high:.2f}")
    assert v_low > v_high, "v_max debe disminuir con κ"
    print("  ✓ PASSED")


def test_loss_of_control():
    """Test 7: Detección de pérdida de control"""
    print("\n[TEST 7] Pérdida de control...")
    mu, g, kappa = 0.9, 9.81*100, 0.1
    vmax = v_max(mu, g, kappa)
    assert not check_loss_of_control(vmax * 0.5, mu, g, kappa), "No debe perder con v < v_max"
    assert check_loss_of_control(vmax * 1.5, mu, g, kappa), "Debe perder con v > v_max"
    print(f"  v_max = {vmax:.2f}, pérdida detectada correctamente")
    print("  ✓ PASSED")


def test_vehicle_simulator():
    """Test 8: Simulador de vehículo"""
    print("\n[TEST 8] Simulador de vehículo...")
    curve = make_circle(50, n=200)
    kappas = curvature_along_curve(curve)
    s_param = arc_param(curve)
    
    vehicle = VehicleSimulator(mu=0.9, g=981.0)
    assert vehicle.speed == 0.0, "Velocidad inicial debe ser 0"
    assert vehicle.arc_pos == 0.0, "Posición inicial debe ser 0"
    
    # simular 10 pasos
    for i in range(10):
        vehicle.state = vehicle.update(0.016, curve, kappas, s_param, user_input_accel=0.5)
        assert vehicle.speed >= 0, "Velocidad no puede ser negativa"
        assert 0 <= vehicle.arc_pos <= 1.0, "arc_pos debe estar en [0,1]"
    
    print(f"  Después de 10 pasos: v = {vehicle.speed:.2f} px/s, s = {vehicle.arc_pos:.4f}")
    assert vehicle.speed > 0, "Velocidad debe haber aumentado con aceleración positiva"
    print("  ✓ PASSED")


def test_catmull_rom_adaptive():
    """Test 9: Spline Catmull-Rom con discretización adaptativa"""
    print("\n[TEST 9] Catmull-Rom adaptativo...")
    # control points en forma de S
    pts_ctrl = [(50, 100), (150, 150), (200, 200), (150, 250), (50, 300)]
    curve_regular = catmull_rom_chain(pts_ctrl, samples_per_segment=50, adaptive=False)
    curve_adaptive = catmull_rom_chain(pts_ctrl, samples_per_segment=50, adaptive=True)
    
    print(f"  Regular: {len(curve_regular)} puntos")
    print(f"  Adaptativo: {len(curve_adaptive)} puntos")
    assert len(curve_adaptive) > len(curve_regular), "Adaptativo debe tener más puntos en zonas curvas"
    print("  ✓ PASSED")


def run_all():
    print("=" * 60)
    print("CURVA RACER - SUITE DE TESTS")
    print("=" * 60)
    
    try:
        test_circle()
        test_line()
        test_parabola()
        test_arc_length()
        test_arc_param()
        test_physics_vmax()
        test_loss_of_control()
        test_vehicle_simulator()
        test_catmull_rom_adaptive()
        
        print("\n" + "=" * 60)
        print("✓ TODOS LOS TESTS PASARON")
        print("=" * 60)
        return True
    except AssertionError as e:
        print(f"\n✗ FALLO: {e}")
        return False


if __name__ == '__main__':
    success = run_all()
    exit(0 if success else 1)
