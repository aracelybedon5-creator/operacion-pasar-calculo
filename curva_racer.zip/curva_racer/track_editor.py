"""Funciones auxiliares para manipular puntos de control y persistencia simple.
Actualmente contiene utilidades básicas; puede ampliarse para guardar/abrir pistas, herramientas de edición, etc.
"""
import json
import os


def save_control_points(path, points):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump([list(p) for p in points], f)


def load_control_points(path):
    if not os.path.exists(path):
        return []
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return [tuple(p) for p in data]
